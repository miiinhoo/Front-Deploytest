
import Header from '../layouts/Header';

const main = () => {
    return(
        <div className="main">
            <Header/>
        </div>
    )
}
export default main;