export const COLUMNS = [
  { id: "bomId", label: "BOM ID", key: "bomId" },
  { id: "itemName", label: "완제품", key: "itemName" },
  { id: "partName", label: "부품", key: "partName" },
  { id: "qtyPerItem", label: "수량", key: "qtyPerItem" },
];