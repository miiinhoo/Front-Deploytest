

const CloseBtnComponent = ({onClose}) => {

    return(
        <>
            <button onClick={onClose} className="closeBtn"></button>
        </>
            

    );
}
export default CloseBtnComponent;