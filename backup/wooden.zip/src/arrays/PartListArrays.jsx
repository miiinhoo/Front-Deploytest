export const PartListArray = [            
  { id: 1, clmn: "partNo", input: "number",content: "일련번호" },
  { id: 2, clmn: "partName", input: "text", content: "부품명" },
  { id: 3, clmn: "buyerComp", input: "select",content: "구매처명" },


  { id: 4, clmn: "partCode", input: "text", content: "부품코드" },
  { id: 5, clmn: "partSpec", input: "text", content: "부품규격" },
  { id: 6, clmn: "partPrice", input: "text", content: "부품단가" },
];
